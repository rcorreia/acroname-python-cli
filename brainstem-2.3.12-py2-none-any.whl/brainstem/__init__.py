"""
A Package that enables communication with Acroname Brainstem Modules and
BrainStem networks.


"""

from sys import platform
import os
from _brainstem_c import ffi
from platform import architecture

arch, plat = architecture()

# Initialize the Brainstem C binding in init.
# Then you can import like so; 'from brainstem import _BS_C, ffi'
_BS_C = None

if platform.startswith('darwin'):
    _BS_C = ffi.dlopen(os.path.join(os.path.dirname(os.path.realpath(__file__)),'BrainStem2'))
elif platform.startswith('win32'):
    if arch.startswith('32'):
        _BS_C = ffi.dlopen(os.path.join(os.path.dirname(os.path.realpath(__file__)),'x86', 'BrainStem2'))
    else:
    	_BS_C = ffi.dlopen(os.path.join(os.path.dirname(os.path.realpath(__file__)),'x64', 'BrainStem2'))
elif platform.startswith('linux'):
    _BS_C = ffi.dlopen(os.path.join(os.path.dirname(os.path.realpath(__file__)),'libBrainStem2.so'))
else:
    raise ImportError("Platform not supported")

import link
import discover
import stem
import defs
import version
